import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Gamepad2, Users, Globe, ExternalLink, ArrowLeft, Search, PlusCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

const SERVERS = [];

export default function Directory() {
  return (
    <div className="min-h-screen gradient-dark p-6 md:p-12">
      <div className="max-w-6xl mx-auto">
        <Link href="/">
          <Button variant="ghost" className="mb-8 text-muted-foreground hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-display font-bold text-white mb-2">Server Directory</h1>
            <p className="text-muted-foreground text-lg">Browse and join private game servers</p>
          </div>
          <Button className="gradient-blurple">
            <PlusCircle className="w-4 h-4 mr-2" />
            Register Server
          </Button>
        </div>

        <div className="flex gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input className="pl-10 bg-white/5 border-white/10 h-12" placeholder="Search servers or games..." />
          </div>
          <Button variant="outline" className="h-12 border-white/10">Filters</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SERVERS.length > 0 ? (
            SERVERS.map((server) => (
              <Card key={server.name} className="glass p-6 hover:border-blue-500/30 transition-all">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center">
                      <Gamepad2 className="w-6 h-6 text-blue-400" />
                    </div>
                    <div>
                      <h3 className="font-bold text-white text-lg">{server.name}</h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-[10px] uppercase py-0">{server.game}</Badge>
                        <span className="text-muted-foreground text-xs flex items-center gap-1">
                          <Globe className="w-3 h-3" />
                          {server.region}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Badge className={
                    server.status === 'Public' ? 'bg-green-500/20 text-green-400' : 
                    server.status === 'Private' ? 'bg-amber-500/20 text-amber-400' :
                    'bg-red-500/20 text-red-400'
                  }>
                    {server.status}
                  </Badge>
                </div>

                <div className="flex items-center justify-between mt-auto pt-6 border-t border-white/5">
                  <div className="flex items-center gap-2 text-sm">
                    <Users className="w-4 h-4 text-muted-foreground" />
                    <span className="text-white font-medium">{server.players}</span>
                  </div>
                  <Button size="sm" className="gradient-blurple">
                    Join Server
                    <ExternalLink className="w-3 h-3 ml-2" />
                  </Button>
                </div>
              </Card>
            ))
          ) : (
            <div className="col-span-full py-20 text-center">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">No servers found</h3>
              <p className="text-muted-foreground">The directory is currently empty. Check back later!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
