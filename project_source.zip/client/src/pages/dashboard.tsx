import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  LayoutDashboard, 
  Settings, 
  Users, 
  BarChart3, 
  MessageSquare, 
  Shield, 
  Power, 
  Terminal, 
  Zap, 
  Lock,
  LogOut,
  Bell,
  Search,
  Check,
  ChevronRight,
  Monitor,
  Cpu,
  Database,
  Radio,
  Crown,
  Sparkles,
  User,
  Clock,
  History,
  AlertTriangle,
  Play,
  Square,
  Plus
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AnalyticsView from "@/components/dashboard/AnalyticsView";

function StaffManagement() {
  const [onShift, setOnShift] = useState(false);
  const [shiftTime, setShiftTime] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    let interval: any;
    if (onShift) {
      interval = setInterval(() => setShiftTime(prev => prev + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [onShift]);

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const infractions = [
    { id: 1, user: "jake_dev", type: "Warning", reason: "Spamming in #general", staff: "amaze_jt", date: "2026-01-15" },
    { id: 2, user: "sarah_mod", type: "Note", reason: "Good participation in event", staff: "system", date: "2026-01-14" },
    { id: 3, user: "user_123", type: "Warning", reason: "Inappropriate language", staff: "amaze_jt", date: "2026-01-14" },
  ];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass p-4 border-white/5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400"><Clock className="w-5 h-5" /></div>
            <div><p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Weekly Hours</p><p className="text-xl font-bold text-white">14.5h</p></div>
          </div>
        </Card>
        <Card className="glass p-4 border-white/5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-green-500/10 text-green-400"><Check className="w-5 h-5" /></div>
            <div><p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Shifts Completed</p><p className="text-xl font-bold text-white">12</p></div>
          </div>
        </Card>
        <Card className="glass p-4 border-white/5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-yellow-500/10 text-yellow-400"><AlertTriangle className="w-5 h-5" /></div>
            <div><p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Warnings Issued</p><p className="text-xl font-bold text-white">42</p></div>
          </div>
        </Card>
        <Card className="glass p-4 border-white/5">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400"><Shield className="w-5 h-5" /></div>
            <div><p className="text-[10px] text-muted-foreground uppercase font-bold tracking-wider">Staff Level</p><p className="text-xl font-bold text-white">Admin</p></div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="space-y-6">
          <Card className="glass border-white/5 overflow-hidden">
            <div className="p-6 border-b border-white/5 bg-white/5"><h3 className="text-lg font-bold text-white">Shift Manager</h3><p className="text-xs text-muted-foreground">Track your activity.</p></div>
            <div className="p-8 text-center">
              <div className="mb-6"><div className={`text-5xl font-mono font-bold transition-colors ${onShift ? 'text-blue-400 glow-text-blue' : 'text-muted-foreground'}`}>{formatTime(shiftTime)}</div><p className="text-xs text-muted-foreground mt-2 uppercase tracking-widest font-bold">{onShift ? 'Active Session' : 'Inactive'}</p></div>
              <Button onClick={() => setOnShift(!onShift)} className={`w-full py-8 h-auto text-lg transition-all ${onShift ? 'bg-red-500/10 text-red-400 border border-red-500/20 hover:bg-red-500/20' : 'gradient-blurple'}`}>{onShift ? <><Square className="w-5 h-5 mr-3" /> End Shift</> : <><Play className="w-5 h-5 mr-3" /> Start Shift</>}</Button>
            </div>
          </Card>
        </div>
        <div className="lg:col-span-2">
          <Tabs defaultValue="infractions" className="w-full">
            <TabsList className="bg-white/5 border border-white/10 w-full justify-start h-12 p-1 gap-2">
              <TabsTrigger value="infractions">Infractions</TabsTrigger>
              <TabsTrigger value="lookup">User Lookup</TabsTrigger>
            </TabsList>
            <TabsContent value="infractions" className="mt-6 space-y-4">
              <Card className="glass border-white/5 overflow-hidden">
                <table className="w-full text-left">
                  <thead className="bg-white/5 border-b border-white/5">
                    <tr><th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase">User</th><th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase">Type</th><th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase">Reason</th><th className="px-6 py-4 text-[10px] font-bold text-muted-foreground uppercase text-right">Date</th></tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {infractions.map((inf) => (
                      <tr key={inf.id} className="hover:bg-white/5 transition-colors">
                        <td className="px-6 py-4 flex items-center gap-3"><div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center"><User className="w-4 h-4 text-blue-400" /></div><span className="text-sm font-medium text-white">{inf.user}</span></td>
                        <td className="px-6 py-4"><Badge className={inf.type === 'Warning' ? 'bg-yellow-500/10 text-yellow-400' : 'bg-blue-500/10 text-blue-400'}>{inf.type}</Badge></td>
                        <td className="px-6 py-4 text-xs text-muted-foreground">{inf.reason}</td>
                        <td className="px-6 py-4 text-xs text-muted-foreground text-right">{inf.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("bot");

  const sidebarItems = [
    { id: "bot", label: "Bot Settings", icon: Radio },
    { id: "premium", label: "Premium Dashboard", icon: Crown, premium: true },
    { id: "staff", label: "Staff & Shifts", icon: Users },
    { id: "infractions", label: "Infractions", icon: Shield },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "security", label: "Security", icon: Lock },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case "bot":
        return (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="glass p-6 border-white/5"><Monitor className="w-6 h-6 text-blue-400 mb-4" /><p className="text-muted-foreground text-sm font-medium">Gateway Status</p><h4 className="text-2xl font-bold text-white">Connected</h4></Card>
              <Card className="glass p-6 border-white/5"><Zap className="w-6 h-6 text-purple-400 mb-4" /><p className="text-muted-foreground text-sm font-medium">Heartbeat Latency</p><h4 className="text-2xl font-bold text-white">42ms</h4></Card>
              <Card className="glass p-6 border-white/5"><Database className="w-6 h-6 text-orange-400 mb-4" /><p className="text-muted-foreground text-sm font-medium">Data Storage</p><h4 className="text-2xl font-bold text-white">Synced</h4></Card>
            </div>
            <Card className="glass border-white/5 overflow-hidden">
              <div className="p-6 border-b border-white/5 bg-white/5"><h3 className="text-lg font-bold text-white">Integration Controls</h3></div>
              <div className="divide-y divide-white/5">
                {[
                  { icon: Terminal, title: "Slash Commands (v14)", color: "text-blue-400" },
                  { icon: Zap, title: "Premium Features", color: "text-yellow-400" },
                  { icon: Users, title: "Shared Staff Database", color: "text-purple-400" }
                ].map((item, i) => (
                  <div key={i} className="p-6 flex items-center justify-between">
                    <div className="flex gap-4"><item.icon className={`w-6 h-6 ${item.color}`} /><div><p className="text-white font-bold">{item.title}</p></div></div>
                    <Switch defaultChecked />
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        );
      case "premium":
        return (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 rounded-2xl gradient-blurple flex items-center justify-center"><Crown className="w-8 h-8 text-white" /></div>
              <div><h3 className="text-3xl font-bold text-white">Premium Dashboard</h3><p className="text-muted-foreground">Manage your active subscriptions.</p></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <Card className="glass p-8 border-white/5"><Zap className="w-8 h-8 text-blue-400 mb-4" /><h4 className="text-xl font-bold text-white mb-6">Subscription Details</h4><div className="space-y-4 text-sm"><div className="flex justify-between border-b border-white/5 pb-2"><span className="text-muted-foreground">Status</span><span className="text-green-400 font-bold">Active</span></div></div></Card>
              <Card className="glass p-8 border-white/5"><Sparkles className="w-8 h-8 text-purple-400 mb-4" /><h4 className="text-xl font-bold text-white mb-6">Features Unlocked</h4><ul className="space-y-3 text-sm">{['Custom Bot Branding', 'Global Economy API'].map(f => <li key={f} className="flex items-center gap-3 text-white/80"><Check className="w-4 h-4 text-green-400" />{f}</li>)}</ul></Card>
            </div>
          </motion.div>
        );
      case "staff":
      case "infractions":
        return <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}><StaffManagement /></motion.div>;
      default:
        return <div className="py-20 text-center"><Search className="w-10 h-10 text-muted-foreground mx-auto mb-6" /><h3 className="text-2xl font-bold text-white">Coming Soon</h3></div>;
    }
  };

  return (
    <div className="min-h-screen gradient-dark flex overflow-hidden">
      <aside className="w-72 glass-strong border-r border-white/5 flex flex-col z-50">
        <div className="p-8"><Link href="/"><div className="flex items-center gap-3 cursor-pointer"><LayoutDashboard className="w-6 h-6 text-blue-400" /><span className="font-display text-xl font-bold text-white">Oxelon</span></div></Link></div>
        <nav className="flex-1 px-4 space-y-1">
          {sidebarItems.map((item) => (
            <button key={item.id} onClick={() => setActiveTab(item.id)} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${activeTab === item.id ? "bg-blue-500/10 text-blue-400 border border-blue-500/20" : "text-muted-foreground hover:text-white"}`}>
              <item.icon className={`w-5 h-5 ${item.premium ? 'text-yellow-400' : ''}`} />
              <span className="font-medium text-sm">{item.label}</span>
              {item.premium && <Badge className="ml-auto text-[8px] bg-yellow-500/20 text-yellow-400">Pro</Badge>}
            </button>
          ))}
        </nav>
        <div className="p-6 border-t border-white/5"><Link href="/"><Button variant="ghost" className="w-full justify-start text-red-400"><LogOut className="w-4 h-4 mr-3" />Log out</Button></Link></div>
      </aside>
      <main className="flex-1 overflow-y-auto p-10 bg-[url('https://www.transparenttextures.com/patterns/dark-matter.png')]">
        <header className="mb-10 flex items-center justify-between"><h2 className="text-2xl font-bold text-white">{sidebarItems.find(i => i.id === activeTab)?.label}</h2><div className="flex items-center gap-4"><Badge variant="outline" className="border-green-500/30 text-green-400">Connected</Badge><div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold text-xs">AJ</div></div></header>
        <AnimatePresence mode="wait">{renderContent()}</AnimatePresence>
      </main>
    </div>
  );
}
