import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Link } from "wouter";
import { LogIn, Shield, ArrowLeft } from "lucide-react";

const LOGO_URL = "https://cdn.discordapp.com/attachments/1448117461357432893/1460803623352008911/IMG_5117.jpg?ex=69683ee4&is=6966ed64&hm=caded6761e270848ce9b1c78678fd66d191580ebdc47332cf96c2d2bf881e013&";

export default function Login() {
  return (
    <div className="min-h-screen gradient-dark flex items-center justify-center p-6">
      <div className="absolute top-8 left-8">
        <Link href="/">
          <Button variant="ghost" className="text-muted-foreground hover:text-white">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <img src={LOGO_URL} alt="Oxelon Logo" className="w-20 h-20 rounded-2xl mx-auto mb-4 glow-blurple object-cover" />
          <h1 className="text-3xl font-display font-bold text-white">Login to Oxelon</h1>
          <p className="text-muted-foreground mt-2">Access your server management portal</p>
        </div>

        <Card className="glass p-8 border-blue-500/20 shadow-2xl">
          <div className="space-y-4">
            <Button className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white py-6 h-auto transition-all transform hover:scale-[1.02] shadow-lg">
              <LogIn className="w-5 h-5 mr-3" />
              Login with Discord
            </Button>
            
            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-border"></div>
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-transparent px-2 text-muted-foreground font-medium">Or using access key</span>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-white mb-2 block">Email Address</label>
                <Input className="bg-background/50 border-border h-12" placeholder="example@icloud.com" />
              </div>
              <div>
                <label className="text-sm font-medium text-white mb-2 block">Password</label>
                <Input className="bg-background/50 border-border h-12" type="password" placeholder="Enter your password." />
              </div>
              <Button variant="outline" className="w-full py-6 h-auto border-border hover:bg-accent text-white">
                Log In
              </Button>
              <div className="text-center">
                <p className="text-xs text-muted-foreground">
                  Don't have an account?{" "}
                  <button className="text-blue-400 hover:underline font-medium">Log in</button>
                </p>
              </div>
            </div>
          </div>
        </Card>

        <p className="text-center text-sm text-muted-foreground mt-8">
          Authorized personnel only. All access is logged and monitored.
        </p>
      </motion.div>
    </div>
  );
}
