
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Shield, Hammer, Ban, Clock, LayoutDashboard, Server, 
  FileWarning, Key, Users, Car, Radio, Gamepad2, 
  ChevronRight, Terminal, Sparkles, Zap, Globe, 
  ExternalLink, LogIn, Layout, Layers, Cpu, Crown, Star, Rocket, Menu, X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";

const LOGO_URL = "https://cdn.discordapp.com/attachments/1448117461357432893/1460803623352008911/IMG_5117.jpg?ex=69683ee4&is=6966ed64&hm=caded6761e270848ce9b1c78678fd66d191580ebdc47332cf96c2d2bf881e013&";
const INVITE_URL = "https://discord.com/oauth2/authorize?client_id=1458952696974409929&permissions=8&response_type=code&redirect_uri=https%3A%2F%2Fdiscord.com%2Foauth2%2Fauthorize%3Fclient_id%3D1458952696974409929&integration_type=0&scope=identify+connections+guilds+bot";
const SUPPORT_URL = "https://discord.gg/3NZzQeUnJU";

export default function Home() {
  const [showInstructions, setShowInstructions] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const features = [
    { icon: Shield, title: "Advanced Moderation", desc: "Keep your community safe with warns, kicks, bans, and timeouts. Robust logging included." },
    { icon: Cpu, title: "Roblox Integration", desc: "Real-time game API support for ERLC, Maple County, and more. Live status updates." },
    { icon: Layout, title: "Public Web Dashboard", desc: "Manage your server settings from our beautiful, mobile-friendly web interface." },
    { icon: Layers, title: "Infraction System", desc: "Formal logging and professional embeds for all disciplinary actions across your community." },
    { icon: Users, title: "Staff & Management", desc: "Tools for application systems, tickets, and internal staff communication." },
    { icon: Zap, title: "Lightning Fast", desc: "Global distribution ensures your commands are processed instantly anywhere in the world." },
    { icon: Radio, title: "Announcement System", desc: "Automated community updates and scheduled server announcements." },
    { icon: Terminal, title: "Command Center", desc: "Full control via Discord or our custom web-based console interface." },
    { icon: Globe, title: "Global Economy", desc: "Built-in server economy with shops, trading, and cross-server balances." },
  ];

  return (
    <div className="min-h-screen gradient-dark overflow-x-hidden">
      <nav className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer">
              <img src={LOGO_URL} alt="Oxelon Logo" className="w-10 h-10 rounded-xl object-cover glow-blurple" />
              <span className="font-display text-xl font-bold text-white">Oxelon</span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="hidden md:flex items-center gap-4">
              <Link href="/commands">
                <Button variant="ghost" className="text-muted-foreground hover:text-white">Commands</Button>
              </Link>
              <Link href="/directory">
                <Button variant="ghost" className="text-muted-foreground hover:text-white">Directory</Button>
              </Link>
              <Link href="/premium">
                <Button variant="ghost" className="text-muted-foreground hover:text-white">Premium</Button>
              </Link>
              <a href={SUPPORT_URL} target="_blank" rel="noreferrer">
                <Button variant="ghost" className="text-muted-foreground hover:text-white">Support</Button>
              </a>
              <Link href="/login">
                <Button variant="ghost" className="text-muted-foreground hover:text-white">
                  <LogIn className="w-4 h-4 mr-2" />
                  Login
                </Button>
              </Link>
              <a href={INVITE_URL} target="_blank" rel="noreferrer">
                <Button className="gradient-blurple hover:opacity-90 transition-opacity shadow-lg">
                  <Sparkles className="w-4 h-4 mr-2" />
                  Invite Now
                </Button>
              </a>
            </div>
            <Button 
              size="icon" 
              variant="ghost" 
              className="text-white ml-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </Button>
          </div>
        </div>

        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="md:hidden glass-strong border-t border-white/5 p-6 space-y-4 flex flex-col"
            >
              <Link href="/login" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-white">Login or Sign Up</Button>
              </Link>
              <Link href="/dashboard" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-white">Dashboard</Button>
              </Link>
              <a href={SUPPORT_URL} target="_blank" rel="noreferrer" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-white">Support</Button>
              </a>
              <Link href="/moderation" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-white">Moderation Panel (Staff Only)</Button>
              </Link>
              <Link href="/staff" onClick={() => setIsMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start text-white">Staff</Button>
              </Link>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <section className="pt-32 pb-20 px-6 relative">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-blue-600/10 rounded-full blur-3xl" />
        </div>
        
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="command-tag mb-6 px-4 py-2 text-sm font-medium">
              <Zap className="w-3 h-3 mr-2 text-blue-400" />
              Beta 1.0 | Operational
            </Badge>
            
            <h1 className="text-4xl md:text-7xl font-display font-bold mb-6 leading-tight">
              <span className="text-white">Elevate Your Discord</span>
              <br />
              <span className="text-gradient">Community</span>
            </h1>
            
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 px-4">
              Oxelon provides all-in-one moderation, management, and game integration tools
              for the modern Discord experience.
            </p>
            
            <div className="flex flex-col items-center gap-6">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full px-6 md:px-0">
                <a href={INVITE_URL} target="_blank" rel="noreferrer" className="w-full sm:w-auto">
                  <Button 
                    size="lg" 
                    className="gradient-blurple hover:opacity-90 text-lg px-8 py-6 h-auto w-full" 
                  >
                    Add Oxelon Now
                  </Button>
                </a>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-lg px-8 py-6 h-auto border-border hover:bg-accent w-full sm:w-auto text-white"
                  onClick={() => setShowInstructions(!showInstructions)}
                >
                  Quick Setup Guide
                </Button>
              </div>

              <AnimatePresence>
                {showInstructions && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="w-full max-w-lg mt-8 text-left px-4 md:px-0"
                  >
                    <Card className="glass p-6 border-blue-500/30">
                      <h3 className="font-display text-xl font-bold text-white mb-4">How to Get Started</h3>
                      <ol className="space-y-4 text-muted-foreground">
                        <li className="flex gap-3">
                          <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm shrink-0">1</span>
                          <p>Click <a href={INVITE_URL} className="text-white font-medium underline">Invite</a> to add Oxelon to your guild.</p>
                        </li>
                        <li className="flex gap-3">
                          <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm shrink-0">2</span>
                          <p>Join our <a href={SUPPORT_URL} className="text-white font-medium underline">Support Server</a> for community help.</p>
                        </li>
                        <li className="flex gap-3">
                          <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-sm shrink-0">3</span>
                          <p>Set up your <Link href="/login" className="text-white font-medium underline">Web Dashboard</Link> config.</p>
                        </li>
                      </ol>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="features" className="py-20 px-6 bg-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
             {features.map((feature, i) => (
              <Card key={feature.title} className="glass p-8 border-white/5 hover:border-blue-500/30 transition-all">
                <div className="w-12 h-12 rounded-xl gradient-blurple flex items-center justify-center mb-6">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1">
            <Badge className="bg-blue-500/20 text-blue-400 mb-4 px-4 py-1">Premium Features</Badge>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-white mb-6">Built for Success</h2>
            <p className="text-xl text-muted-foreground mb-8">
              Unlock the full potential of Oxelon with custom branding, advanced analytics, and automated promotion systems.
            </p>
            <Link href="/premium">
              <Button size="lg" className="gradient-blurple text-lg px-10 py-6 h-auto">View Premium Plans</Button>
            </Link>
          </div>
          <div className="flex-1 grid grid-cols-2 gap-4 w-full">
            <Card className="glass p-6 text-center border-white/5">
              <Crown className="w-8 h-8 text-yellow-400 mx-auto mb-3" />
              <div className="text-white font-bold">Custom Logos</div>
            </Card>
            <Card className="glass p-6 text-center border-white/5">
              <Zap className="w-8 h-8 text-blue-400 mx-auto mb-3" />
              <div className="text-white font-bold">Fast API</div>
            </Card>
            <Card className="glass p-6 text-center border-white/5">
              <Star className="w-8 h-8 text-purple-400 mx-auto mb-3" />
              <div className="text-white font-bold">Priority Help</div>
            </Card>
            <Card className="glass p-6 text-center border-white/5">
              <Rocket className="w-8 h-8 text-green-400 mx-auto mb-3" />
              <div className="text-white font-bold">Early Access</div>
            </Card>
          </div>
        </div>
      </section>

      <footer className="py-12 px-6 border-t border-border bg-background">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <img src={LOGO_URL} alt="Oxelon Logo" className="w-10 h-10 rounded-xl object-cover" />
              <span className="font-display text-2xl font-bold text-white">Oxelon</span>
            </div>
            <p className="text-muted-foreground max-w-sm mb-6">
              Empowering Discord communities with the world's most advanced moderation and Roblox integration bot.
            </p>
            <div className="flex gap-4">
              <a href={SUPPORT_URL} target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-white transition-colors">
                Support
              </a>
              <Link href="/tos" className="text-muted-foreground hover:text-white transition-colors">Terms of Service</Link>
              <Link href="/premium" className="text-muted-foreground hover:text-white transition-colors">Premium</Link>
            </div>
          </div>
          <div className="md:ml-auto col-span-1">
            <h4 className="font-display font-bold text-white mb-4">Product</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/commands" className="text-muted-foreground hover:text-blue-400">Commands</Link></li>
              <li><Link href="/directory" className="text-muted-foreground hover:text-blue-400">Directory</Link></li>
              <li><Link href="/premium" className="text-muted-foreground hover:text-blue-400">Premium</Link></li>
              <li><Link href="/chat" className="text-muted-foreground hover:text-blue-400">Support Chat</Link></li>
            </ul>
          </div>
          <div className="md:ml-auto col-span-1">
            <h4 className="font-display font-bold text-white mb-4">Internal</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/staff" className="text-muted-foreground hover:text-blue-400">Staff Portal</Link></li>
              <li><Link href="/moderation" className="text-muted-foreground hover:text-blue-400">Moderation Panel (Staff Only)</Link></li>
              <li><Link href="/login" className="text-muted-foreground hover:text-blue-400">Sign Up</Link></li>
              <li><a href="#" className="text-muted-foreground hover:text-blue-400">Security Logs</a></li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-white/5 text-center md:text-left">
          <span className="text-muted-foreground text-sm">© 2026 Oxelon. Build for the community.</span>
        </div>
      </footer>
    </div>
  );
}
